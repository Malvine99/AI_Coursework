using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class LeafNode : BaseNode
{

    public override void ResetNode()
    {
        base.ResetNode();
    }
}
